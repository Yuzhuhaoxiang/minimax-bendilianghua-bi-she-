# MiniMax H3 ref2v 工作流参考

本地 ComfyUI 里用 `MiniMaxH3ReferenceToVideo` 做"参考图 + 参考视频 → 新视频"。

## 模型清单

| 槽位 | 文件 | 大小 |
|---|---|---|
| diffusion_models | `minimax_h3_ref2va_pruned_int8_convrot.safetensors` | ~20 GB |
| text_encoders | `qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors` | ~15 GB |
| vae（视频） | `minimax_h3_video_vae_int8_convrot.safetensors` | ~2.7 GB |
| vae（音频） | `minimax_h3_audio_vae_fp32.safetensors` | ~0.6 GB |
| loras | `minimax_h3_ref2v_turbo_4step_v0.1_comfyui_bf16.safetensors` | ~1.9 GB |

另有 `fl2va`（首尾帧生视频）一套，与 ref2v 权重不同，不能混用。

## 节点图

```
UNETLoader ──┐
             ├─ LoraLoaderModelOnly(4step) ─┬─ BasicGuider ─┐
CLIPLoader ──┼─ MiniMaxH3ReferenceToVideo ──┘              ├─ SamplerCustomAdvanced ─┬─ VAEDecode(video vae)
VAELoader×2 ─┘        (输出 conditioning + latent)          │                        └─ VAEDecodeAudio(audio vae)
                                                            │                              ↓
RandomNoise ────────────────────────────────────────────────┤                        CreateVideo(24fps)
KSamplerSelect(res_multistep) ──────────────────────────────┤                              ↓
BasicScheduler(beta, 4, 1.0) ───────────────────────────────┘                        SaveVideo
```

采样器跑完的 `LATENT` 是音视频打包体，`VAEDecode` 与 `VAEDecodeAudio` 各自取自己那一半。

## 关键参数

- `width` / `height`：`MiniMaxH3ReferenceToVideo` 自己出 latent，不需要 EmptyLatent。
  官方建议 768 短边、总面积 ≤ 768×1344。8 GB 显存实践值 **960×544（0.52 MP）**，
  再往上会明显变慢甚至 OOM。
- `length`：帧数必须是 **17k+5**（24fps），例如 73 ≈ 3.04 s、124 ≈ 5.2 s、158 ≈ 6.6 s。
  给别的数字会被自动吸附到网格上。
- `ref_image_size`：`match`（缩到生成分辨率，快）或 `max`（保留 2048 短边，慢数倍）。
  日常用 `match`。
- 采样：`res_multistep` + `beta` + **4 步**（turbo LoRA 就是 4 步训练的，加到 20 步没有收益）。
- `seed`：同一套素材换种子差异**极大**——鱼的条数、机位、色调都会变。要出稳定结果必须多跑几条挑。

## 参考输入的语义

`MiniMaxH3ReferenceToVideo` 支持最多 9 张参考图、3 段参考视频、3 段参考音频，
提示词里用 `<Picture 1>` / `<Video 1>` / `<Audio 1>` 按连接顺序引用。

实测两者的话语权：

- **参考图决定画风、配色、机位**。给侧视锚图 → 输出就是侧视特写；给俯视锚图 → 输出才俯视。
- **参考视频决定运动、构图、节奏，但会连材质一起继承**。母版是米色宣纸，输出就是米色宣纸；
  母版是写实沙滩，输出就是写实沙滩。提示词改不动这一层。

结论：**先改母版的颜色/材质，再交给模型**（见 `prep_master.py`），比反复调提示词有效得多。

## API 上的坑

1. **Autogrow 输入的键名**必须写成 `<组名>.<子名>`：
   `"ref_images.ref_image_0"`、`"ref_videos.ref_video_0"`。
   写 `ref_image_0` 报 `unexpected keyword argument`；
   写 `ref_images` 报 `Boolean value of Tensor with more than one value is ambiguous`。
2. `LoadImage` 只从 input 目录读，`SaveImage` 写到 output 目录。上一张生成的图要**手动拷回 input**。
3. 视频输入走 `LoadVideo → GetVideoComponents`，取 `images` 接到 `ref_video_0`。
4. 5.2 的节点名是 `ShaderNodeVolumePrincipled`（不是 `ShaderNodePrincipledVolume`）；
   Action 没有 `.fcurves`，要走 `action.layers[].strips[].channelbags[].fcurves`。

## 性能（RTX 4060 Laptop 8 GB / 32 GB RAM）

| 帧数 | 有无参考视频 | 单条耗时 |
|---|---|---|
| 73 | 仅参考图 | ~90 s |
| 73 | 图 + 视频 | ~5–6 min |
| 158 | 图 + 视频 | ~10–12 min |

模型 20 GB 装不进 8 GB 显存，ComfyUI 会做权重流式加载（日志里 `Using async weight offloading`）。
偶发 `HostBuffer.read_file_slice failed`，**直接重试一次即可**，不是配置问题。

## 音频

H3 会原生生成音轨（水下声、机械声、配乐都可能出现）。

- 要"无配乐/静音"：`vid_utils.py mute` 或重新封装时只保留视频流。
- 要"保留母版原声"：用 `add_stream_from_template` 做流拷贝（见 `prep_master._mux_audio`）。
  注意 **PyAV 18 里 `oc.add_stream(template=stream)` 会报 TypeError**，必须用
  `oc.add_stream_from_template(stream)`。
