# -*- coding: utf-8 -*-
"""母版预处理：在交给 AI 之前，用确定性变换把参考视频"染"成目标画风的底色。

为什么需要：MiniMax H3 的 ref2v 会强烈继承参考视频的材质与色调。
只靠提示词改不动底色（米色宣纸、黑墨块、写实沙滩都会被照搬）。
所以先把母版转成目标色系，再让模型只做"提质"。

用法：
    python prep_master.py in.mp4 out.mp4 --preset cool_duotone
    python prep_master.py in.mp4 out.mp4 --preset gray_highkey --lo 18 --hi 205
    python prep_master.py in.mp4 out.mp4 --preset none --strip-audio

预设：
    none           原样转码（只用于换容器/去音轨）
    gray_highkey   灰度 + 提亮曲线，保留中间调（黑白赛璐珞动画）
    faded_gray     灰度 + 抬黑场（母版里有大片死黑时用，注意可能诱发复制）
    cool_duotone   亮度映射成 深青绿→近白，用 redness 遮罩保住暖色主体（吉卜力水彩底）
    warm_paper     米黄纸底 + 深褐墨（水墨/国潮底）
"""
import argparse
import os
import sys

import av
import numpy as np
from PIL import Image, ImageOps


def _lut_gray(lo, hi, gamma):
    lut = []
    for v in range(256):
        if v <= lo:
            x = 0.0
        elif v >= hi:
            x = 1.0
        else:
            x = (v - lo) / float(hi - lo)
            x = x ** gamma
        lut.append(int(round(x * 255)))
    return lut


def gray_highkey(im, lo=18, hi=205, gamma=0.95, **_):
    g = ImageOps.grayscale(im).point(_lut_gray(lo, hi, gamma))
    return g.convert("RGB")


def faded_gray(im, lo=60, hi=248, gamma=0.9, **_):
    g = ImageOps.grayscale(im).point(_lut_gray(lo, hi, gamma))
    return g.convert("RGB")


def cool_duotone(im, deep=(0.16, 0.30, 0.30), light=(0.93, 0.97, 0.95),
                 keep_warm=True, warm_gain=3.2, **_):
    a = np.asarray(im, dtype=np.float32) / 255.0
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
    t = np.clip((lum - 0.35) / 0.55, 0, 1)[..., None]
    d = np.array(deep, np.float32)[None, None, :]
    l = np.array(light, np.float32)[None, None, :]
    bg = d * (1 - t) + l * t
    if keep_warm:
        redness = np.clip(r - np.maximum(g, b), 0, 1)
        warm = np.stack([np.clip(lum * 1.15 + 0.05, 0, 1),
                         np.clip(lum * 0.95, 0, 1),
                         np.clip(lum * 0.90, 0, 1)], axis=-1)
        m = np.clip(redness * warm_gain, 0, 1)[..., None]
        out = bg * (1 - m) + warm * m
    else:
        out = bg
    return Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8), "RGB")


def warm_paper(im, dark=(0.22, 0.16, 0.10), paper=(0.94, 0.90, 0.80), **_):
    a = np.asarray(ImageOps.grayscale(im), dtype=np.float32) / 255.0
    t = np.clip(a, 0, 1)[..., None]
    d = np.array(dark, np.float32)[None, None, :]
    l = np.array(paper, np.float32)[None, None, :]
    out = d * (1 - t) + l * t
    return Image.fromarray((np.clip(out, 0, 1) * 255).astype(np.uint8), "RGB")


PRESETS = {
    "none": lambda im, **k: im.convert("RGB"),
    "gray_highkey": gray_highkey,
    "faded_gray": faded_gray,
    "cool_duotone": cool_duotone,
    "warm_paper": warm_paper,
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--preset", default="none", choices=sorted(PRESETS))
    ap.add_argument("--lo", type=int, default=None)
    ap.add_argument("--hi", type=int, default=None)
    ap.add_argument("--gamma", type=float, default=None)
    ap.add_argument("--strip-audio", action="store_true")
    ap.add_argument("--keep-audio", action="store_true", help="保留原音轨（默认丢弃）")
    ap.add_argument("--bitrate", default="6000k")
    args = ap.parse_args()

    fn = PRESETS[args.preset]
    kw = {}
    if args.lo is not None:
        kw["lo"] = args.lo
    if args.hi is not None:
        kw["hi"] = args.hi
    if args.gamma is not None:
        kw["gamma"] = args.gamma

    os.makedirs(os.path.dirname(os.path.abspath(args.dst)), exist_ok=True)

    with av.open(args.src) as ic, av.open(args.dst, mode="w") as oc:
        ist = ic.streams.video[0]
        ost = oc.add_stream("libx264", rate=ist.average_rate)
        ost.width, ost.height, ost.pix_fmt = ist.width, ist.height, "yuv420p"
        ost.bit_rate = int(args.bitrate.rstrip("k")) * 1000
        n = 0
        for fr in ic.decode(video=0):
            im = fn(fr.to_image(), **kw)
            for pkt in ost.encode(fr.from_image(im).reformat(format="yuv420p")):
                oc.mux(pkt)
            n += 1
        for pkt in ost.encode():
            oc.mux(pkt)
        print(f"{n} frames -> {args.dst} (preset={args.preset})")

    if args.keep_audio:
        _mux_audio(args.src, args.dst)
    elif not args.strip_audio:
        print("提示：默认已丢弃音轨；需要保留请加 --keep-audio")


def _mux_audio(src_with_audio, video_file):
    """把 src 的音轨流拷贝进 video_file（就地替换）。"""
    tmp = video_file + ".tmp.mp4"
    with av.open(video_file) as iv, av.open(src_with_audio) as ia_, av.open(tmp, mode="w") as oc:
        if not ia_.streams.audio:
            os.replace(video_file, video_file)
            return
        vs, aus = iv.streams.video[0], ia_.streams.audio[0]
        ov = oc.add_stream_from_template(vs)
        oa = oc.add_stream_from_template(aus)
        for pkt in iv.demux(vs):
            if pkt.dts is None:
                continue
            pkt.stream = ov
            oc.mux(pkt)
        for pkt in ia_.demux(aus):
            if pkt.dts is None:
                continue
            pkt.stream = oa
            oc.mux(pkt)
    os.replace(tmp, video_file)


if __name__ == "__main__":
    sys.exit(main())
