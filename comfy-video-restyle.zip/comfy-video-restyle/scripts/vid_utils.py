# -*- coding: utf-8 -*-
"""视频小工具（基于 PyAV，不依赖系统 ffmpeg 二进制）。

    python vid_utils.py info  a.mp4
    python vid_utils.py frames a.mp4 outdir 6        # 均匀抽 6 帧
    python vid_utils.py story a.mp4 sheet.png 4      # 2x2 分镜
    python vid_utils.py mute  a.mp4                  # 去掉音轨（就地）
    python vid_utils.py probe_motion a.mp4           # 首尾帧差异，判断是否"没动"
"""
import os
import sys

import av
import numpy as np
from PIL import Image


def info(path):
    with av.open(path) as c:
        v = c.streams.video[0]
        return {
            "duration": round(float(c.duration) / 1e6, 2) if c.duration else None,
            "frames": v.frames,
            "fps": float(v.average_rate) if v.average_rate else None,
            "width": v.width,
            "height": v.height,
            "audio_streams": len(c.streams.audio),
        }


def frames(path, outdir, n=6, scale=None):
    os.makedirs(outdir, exist_ok=True)
    with av.open(path) as c:
        allf = [f.to_image() for f in c.decode(video=0)]
    total = len(allf)
    idx = [int(i * (total - 1) / max(1, n - 1)) for i in range(n)] if total > 1 else [0]
    saved = []
    for i in idx:
        im = allf[i]
        if scale:
            im = im.resize(scale)
        p = os.path.join(outdir, f"f{i:05d}.png")
        im.save(p)
        saved.append(p)
    return saved


def story(path, dst, n=4, cols=2):
    with av.open(path) as c:
        allf = [f.to_image() for f in c.decode(video=0)]
    total = len(allf)
    idx = [int(i * (total - 1) / max(1, n - 1)) for i in range(n)]
    ims = [allf[i] for i in idx]
    w, h = ims[0].size
    rows = (n + cols - 1) // cols
    sheet = Image.new("RGB", (w * cols, h * rows))
    for k, im in enumerate(ims):
        sheet.paste(im, ((k % cols) * w, (k // cols) * h))
    sheet.save(dst)
    return dst


def mute(path):
    tmp = path + ".mute.mp4"
    with av.open(path) as ic, av.open(tmp, mode="w") as oc:
        vs = ic.streams.video[0]
        ov = oc.add_stream_from_template(vs)
        for pkt in ic.demux(vs):
            if pkt.dts is None:
                continue
            pkt.stream = ov
            oc.mux(pkt)
    os.replace(tmp, path)
    return path


def probe_motion(path):
    with av.open(path) as c:
        fr = [np.asarray(f.to_image(), dtype=np.float32) for f in c.decode(video=0)]
    if len(fr) < 2:
        return 0.0
    return round(float(np.abs(fr[0] - fr[-1]).mean()), 2)


if __name__ == "__main__":
    cmd = sys.argv[1]
    p = sys.argv[2]
    if cmd == "info":
        for k, v in info(p).items():
            print(f"{k:14s} {v}")
    elif cmd == "frames":
        print(frames(p, sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 6))
    elif cmd == "story":
        print(story(p, sys.argv[3], int(sys.argv[4]) if len(sys.argv) > 4 else 4))
    elif cmd == "mute":
        print(mute(p))
    elif cmd == "probe_motion":
        print(probe_motion(p))
    else:
        print(__doc__)
