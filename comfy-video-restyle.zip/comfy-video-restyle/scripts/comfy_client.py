# -*- coding: utf-8 -*-
"""ComfyUI 本地客户端：自动定位安装、无头启动、提交工作流、取回产物。

用法（用 ComfyUI 自带 venv 的 python 执行最稳）：
    python comfy_client.py info                 # 打印安装/模型目录
    python comfy_client.py start                # 后台启动服务并等到就绪
    python comfy_client.py models               # 列出可用 checkpoints / unet / lora
    python comfy_client.py stop                 # 停掉本机 8188 上的服务

作为模块：
    from comfy_client import ensure_server, submit, wait, outputs, model_paths
"""
import json
import os
import subprocess
import sys
import time
import urllib.request
import uuid

HOST = "http://127.0.0.1:8188"
CLIENT = str(uuid.uuid4())
DEFAULT_PORT = 8188

MODEL_SUBDIRS = [
    "checkpoints", "clip", "clip_vision", "text_encoders", "diffusion_models", "unet",
    "vae", "loras", "controlnet", "embeddings", "upscale_models", "style_models",
    "ipadapter", "animatediff_models", "vae_approx",
]


# ------------------------------------------------------------------ 定位
def _desktop_settings():
    appdata = os.environ.get("APPDATA", "")
    p = os.path.join(appdata, "Comfy Desktop", "settings.json")
    if os.path.isfile(p):
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def discover():
    """返回 dict(install_dir, comfy_dir, python, models_dir, input_dir, output_dir)。

    优先读 Comfy Desktop 的 settings.json；找不到再扫常见路径。
    """
    st = _desktop_settings()
    install_dir = st.get("installDir") or ""
    models_dirs = st.get("modelsDirs") or []
    models_dir = models_dirs[0] if models_dirs else ""

    comfy_dir = ""
    if install_dir and os.path.isdir(install_dir):
        for name in sorted(os.listdir(install_dir)):
            cand = os.path.join(install_dir, name, "ComfyUI")
            if os.path.isfile(os.path.join(cand, "main.py")):
                comfy_dir = cand
                break

    if not comfy_dir:
        for base in (r"E:/Comfy-Desktop/ComfyUI-Installs", r"C:/Comfy-Desktop/ComfyUI-Installs"):
            if os.path.isdir(base):
                for name in sorted(os.listdir(base)):
                    cand = os.path.join(base, name, "ComfyUI")
                    if os.path.isfile(os.path.join(cand, "main.py")):
                        comfy_dir = cand
                        break
            if comfy_dir:
                break

    python = os.path.join(comfy_dir, ".venv", "Scripts", "python.exe") if comfy_dir else ""
    if python and not os.path.isfile(python):
        python = os.path.join(comfy_dir, ".venv", "bin", "python") if comfy_dir else ""

    if not models_dir:
        guess = os.path.join(os.path.dirname(os.path.dirname(comfy_dir or "")), "ComfyUI-Shared", "models")
        if os.path.isdir(guess):
            models_dir = guess

    return {
        "install_dir": install_dir,
        "comfy_dir": comfy_dir,
        "python": python,
        "models_dir": models_dir,
        "input_dir": st.get("inputDir") or (os.path.join(os.path.dirname(models_dir), "input") if models_dir else ""),
        "output_dir": st.get("outputDir") or (os.path.join(os.path.dirname(models_dir), "output") if models_dir else ""),
    }


def model_paths_yaml(models_dir, path=None):
    """写一份 extra_model_paths.yaml，让无头启动能找到桌面版的模型。"""
    path = path or os.path.join(os.getcwd(), "comfy_model_paths.yaml")
    lines = ["shared:", f"    base_path: {models_dir.rstrip('/')}/"]
    for d in MODEL_SUBDIRS:
        if os.path.isdir(os.path.join(models_dir, d)):
            lines.append(f"    {d}: {d}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return path


# ------------------------------------------------------------------ 服务
def is_up(port=DEFAULT_PORT, timeout=3):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/system_stats", timeout=timeout) as r:
            return "system" in json.loads(r.read().decode())
    except Exception:
        return False


def start(workdir, port=DEFAULT_PORT, wait_s=180, extra_args=None):
    """无头启动 ComfyUI。workdir 用于放 input/output 与日志。"""
    d = discover()
    if not d["comfy_dir"] or not os.path.isfile(d["python"]):
        raise RuntimeError(f"找不到 ComfyUI 安装：{d}")
    os.makedirs(os.path.join(workdir, "in"), exist_ok=True)
    os.makedirs(os.path.join(workdir, "out"), exist_ok=True)
    cfg = model_paths_yaml(d["models_dir"], os.path.join(workdir, "comfy_model_paths.yaml"))

    cmd = [
        d["python"], "main.py",
        "--listen", "127.0.0.1", "--port", str(port),
        "--extra-model-paths-config", cfg,
        "--input-directory", os.path.join(workdir, "in"),
        "--output-directory", os.path.join(workdir, "out"),
        "--disable-auto-launch",
    ] + (extra_args or [])

    log = open(os.path.join(workdir, "comfy_server.log"), "w", encoding="utf-8")
    proc = subprocess.Popen(cmd, cwd=d["comfy_dir"], stdout=log, stderr=subprocess.STDOUT)
    t0 = time.time()
    while time.time() - t0 < wait_s:
        if proc.poll() is not None:
            raise RuntimeError(f"ComfyUI 启动失败，看日志：{os.path.join(workdir, 'comfy_server.log')}")
        if is_up(port):
            return proc
        time.sleep(3)
    raise RuntimeError("ComfyUI 启动超时")


def ensure_server(workdir, port=DEFAULT_PORT):
    if is_up(port):
        return None
    return start(workdir, port=port)


# ------------------------------------------------------------------ API
def _post(path, payload, port=DEFAULT_PORT):
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode())


def _get(path, port=DEFAULT_PORT):
    with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=60) as r:
        return json.loads(r.read().decode())


def submit(prompt, port=DEFAULT_PORT):
    res = _post("/prompt", {"prompt": prompt, "client_id": CLIENT}, port)
    if "prompt_id" not in res:
        raise RuntimeError("提交失败：" + json.dumps(res, ensure_ascii=False)[:1500])
    return res["prompt_id"]


def wait(pid, port=DEFAULT_PORT, timeout=3600, label="", quiet=False):
    t0, last = time.time(), 0
    while time.time() - t0 < timeout:
        try:
            h = _get(f"/history/{pid}", port)
        except Exception:
            h = {}
        if pid in h:
            st = h[pid].get("status", {})
            if st.get("status_str") == "error":
                raise RuntimeError(json.dumps(st, ensure_ascii=False)[:2500])
            return h[pid]
        el = int(time.time() - t0)
        if not quiet and el - last >= 30:
            print(f"  [{label}] {el}s", flush=True)
            last = el
        time.sleep(3)
    raise TimeoutError(f"任务 {pid} 超时")


def outputs(entry):
    files = []
    for out in entry.get("outputs", {}).values():
        for key in ("images", "gifs", "videos", "audio"):
            for it in out.get(key, []) or []:
                if isinstance(it, dict) and "filename" in it:
                    files.append(os.path.join(it.get("subfolder", ""), it["filename"]).lstrip("\\/"))
    return files


def object_info(port=DEFAULT_PORT):
    return _get("/object_info", port)


def list_models(port=DEFAULT_PORT):
    oi = object_info(port)
    def opts(node, field):
        try:
            v = oi[node]["input"]["required"][field][0]
            return v if isinstance(v, list) else []
        except Exception:
            return []
    return {
        "checkpoints": opts("CheckpointLoaderSimple", "ckpt_name"),
        "diffusion_models": opts("UNETLoader", "unet_name"),
        "text_encoders": opts("CLIPLoader", "clip_name"),
        "vae": opts("VAELoader", "vae_name"),
        "loras": opts("LoraLoaderModelOnly", "lora_name"),
    }


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "info"
    if cmd == "info":
        for k, v in discover().items():
            print(f"{k:12s} {v}")
    elif cmd == "start":
        wd = sys.argv[2] if len(sys.argv) > 2 else os.getcwd()
        start(wd)
        print("READY", HOST)
    elif cmd == "models":
        for k, v in list_models().items():
            print(f"== {k}")
            for x in v:
                print("   ", x)
    elif cmd == "stop":
        try:
            import psutil  # noqa
        except Exception:
            pass
        print("请用任务管理器或 pkill -f main.py 停止；脚本内启动的进程句柄由调用方持有")
    else:
        print(__doc__)
